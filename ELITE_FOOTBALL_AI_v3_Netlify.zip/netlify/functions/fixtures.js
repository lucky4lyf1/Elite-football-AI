exports.handler = async (event) => {
  const key = process.env.API_FOOTBALL_KEY;
  const headers = {'content-type':'application/json'};
  if (!key) return {statusCode:503,headers,body:JSON.stringify({error:'API_FOOTBALL_KEY is not configured in Netlify environment variables.'})};
  const p=event.queryStringParameters||{}, days=Math.min(7,Math.max(1,Number(p.days)||2)), league=p.league||'all';
  const from=new Date().toISOString().slice(0,10), to=new Date(Date.now()+days*86400000).toISOString().slice(0,10);
  const auth={'x-apisports-key':key};
  try {
    const q=new URLSearchParams({from,to}); if(league!=='all')q.set('league',league);
    const r=await fetch('https://v3.football.api-sports.io/fixtures?'+q,{headers:auth});
    if(!r.ok)throw new Error('Fixture API returned '+r.status);
    const data=await r.json(); if(data.errors&&Object.keys(data.errors).length)throw new Error(JSON.stringify(data.errors));
    const fixtures=await Promise.all((data.response||[]).slice(0,30).map(async f=>{
      const stats=async team=>{const u=new URLSearchParams({league:String(f.league.id),season:String(f.league.season),team:String(team)});const x=await fetch('https://v3.football.api-sports.io/teams/statistics?'+u,{headers:auth});if(!x.ok)return null;return (await x.json()).response||null};
      const [h,a]=await Promise.all([stats(f.teams.home.id),stats(f.teams.away.id)]);
      return {home:f.teams.home.name,away:f.teams.away.name,date:f.fixture.date,league:f.league.name,goals:{for:{average:{home:h?.goals?.for?.average?.home,away:a?.goals?.for?.average?.away}},against:{average:{home:h?.goals?.against?.average?.home,away:a?.goals?.against?.average?.away}}}};
    }));
    return {statusCode:200,headers,body:JSON.stringify({message:'Loaded '+fixtures.length+' fixtures from API-Football.',fixtures})};
  } catch(e){return {statusCode:502,headers,body:JSON.stringify({error:'Live data service error: '+e.message})};}
};