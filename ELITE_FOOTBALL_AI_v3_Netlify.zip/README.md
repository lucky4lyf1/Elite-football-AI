# ELITE FOOTBALL AI v3

## Deploy
Upload the contents of this ZIP as a new deploy to your existing Netlify site. Keep `index.html`, `netlify.toml`, and the `netlify` folder at the root.

## Enable live fixtures
1. Obtain an API-Football API key and check the provider's current plan, coverage and usage limits.
2. In Netlify, open your site settings and find Environment variables.
3. Add `API_FOOTBALL_KEY` with your private key as its value.
4. Trigger a fresh deploy so the function can read the variable.

## Honest limitations
- Until the API key is configured, live fixture scanning will report that it is unavailable.
- This build uses team season goal averages in a simple Poisson-style model. It is not a guaranteed or fully validated prediction engine.
- Corners, cards, injuries, lineups and current SportyBet odds are not integrated in this version.
- No authorized SportyBet betslip API is connected. The app cannot create a genuine booking code; only SportyBet can issue one for a valid betslip.
- It does not place bets.
